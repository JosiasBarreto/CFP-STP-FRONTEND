import React from 'react';
import {
  Clock,
  Eye,
  RotateCcw,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Ban,
  FileText,
} from 'lucide-react';

export const StatusBadgeAdmin = ({
  estado,
  size = 'md',
}) => {
  const normalizado = (estado || '').toUpperCase();

  const config = {
    RASCUNHO: {
      label: 'Rascunho',
      bg: 'bg-slate-100',
      text: 'text-slate-700',
      border: 'border-slate-300',
      icon: <FileText className="w-3.5 h-3.5" />,
    },
    PENDENTE: {
      label: 'Pendente',
      bg: 'bg-amber-50',
      text: 'text-amber-800',
      border: 'border-amber-300',
      icon: <Clock className="w-3.5 h-3.5 text-amber-600" />,
    },
    EM_ANALISE: {
      label: 'Em Análise',
      bg: 'bg-sky-50',
      text: 'text-sky-800',
      border: 'border-sky-300',
      icon: <Eye className="w-3.5 h-3.5 text-sky-600" />,
    },
    DEVOLVIDA: {
      label: 'Devolvida',
      bg: 'bg-orange-50',
      text: 'text-orange-800',
      border: 'border-orange-300',
      icon: <RotateCcw className="w-3.5 h-3.5 text-orange-600" />,
    },
    CORRIGIDA: {
      label: 'Corrigida',
      bg: 'bg-indigo-50',
      text: 'text-indigo-800',
      border: 'border-indigo-300',
      icon: <RefreshCw className="w-3.5 h-3.5 text-indigo-600" />,
    },
    APROVADA: {
      label: 'Aprovada (Inscrito)',
      bg: 'bg-emerald-50',
      text: 'text-emerald-800',
      border: 'border-emerald-300',
      icon: <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />,
    },
    REJEITADA: {
      label: 'Rejeitada',
      bg: 'bg-rose-50',
      text: 'text-rose-800',
      border: 'border-rose-300',
      icon: <XCircle className="w-3.5 h-3.5 text-rose-600" />,
    },
    CANCELADA: {
      label: 'Cancelada',
      bg: 'bg-zinc-100',
      text: 'text-zinc-700',
      border: 'border-zinc-300',
      icon: <Ban className="w-3.5 h-3.5 text-zinc-500" />,
    },
  };

  const item = config[normalizado] || {
    label: estado || 'Desconhecido',
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-300',
    icon: <FileText className="w-3.5 h-3.5" />,
  };

  const sizeClasses =
    size === 'sm'
      ? 'px-2 py-0.5 text-[10px] gap-1'
      : 'px-2.5 py-1 text-xs gap-1.5 font-bold';

  return (
    <span
      className={`inline-flex items-center rounded-lg border font-semibold tracking-tight shadow-2xs ${item.bg} ${item.text} ${item.border} ${sizeClasses}`}
    >
      {item.icon}
      <span>{item.label}</span>
    </span>
  );
};
