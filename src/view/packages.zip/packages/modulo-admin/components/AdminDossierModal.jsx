import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  User,
  FileText,
  History,
  CheckCircle2,
  XCircle,
  Download,
  FileSpreadsheet,
  MapPin,
  Phone,
  Mail,
  GraduationCap,
  AlertTriangle,
  Eye,
  ExternalLink,
  Award,
  IdCard,
  Clock,
  HeartHandshake,
  Check,
  Copy,
  Edit3,
  Save,
  FileCheck,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { StatusBadgeAdmin } from './StatusBadgeAdmin';
import { adminApi } from '../services/adminApi';

export const AdminDossierModal = ({
  candidatura,
  candidaturasLista = [],
  token,
  onClose,
  onNavigate,
  onAtualizar,
  aoNotificar,
}) => {
  // 3 Abas: 'dossier' (todos os dados unificados), 'documentos' (2ª aba), 'historico' (última aba)
  const [abaAtiva, setAbaAtiva] = useState('dossier');
  const [docSelecionado, setDocSelecionado] = useState(null);
  const [processando, setProcessando] = useState(false);
  const [copiado, setCopiado] = useState(false);

  // Modais de ação rápida
  const [modalReprovarAberto, setModalReprovarAberto] = useState(false);
  const [motivoReprovacao, setMotivoReprovacao] = useState('');
  const [modalAprovarAberto, setModalAprovarAberto] = useState(false);
  const [obsAprovacao, setObsAprovacao] = useState('');

  // Modo de edição / retificação
  const [modoEdicao, setModoEdicao] = useState(false);
  const [dadosEdicao, setDadosEdicao] = useState({
    nome: '',
    nome_pai: '',
    nome_mae: '',
    bi: '',
    nif: '',
    data_nascimento: '',
    sexo: 'Masculino',
    nacionalidade: 'São-tomense',
    naturalidade: 'São Tomé',
    estado_civil: 'Solteiro',
    agregado: '1',
    morada: '',
    distrito: 'Água Grande',
    zona: '',
    contacto: '',
    contacto_alternativo: '',
    email: '',
    habilitacao_literaria: '',
    area_formacao: '',
    formacao_profissional: '',
    experiencia_profissional: '',
    ocupacao: '',
    motivo_inscricao: '',
    situacao_emprego: '',
    deficiente: false,
    tipo_deficiencia: '',
    encaminhado_apoio_social: false,
    instituicao_apoio_social: '',
    autorizacao_divulgacao_dados: true,
    justificacao_correcao: '',
    recolocar_analise: false,
  });

  // Sincroniza dados ao trocar de candidatura
  useEffect(() => {
    if (!candidatura) return;
    setDadosEdicao({
      nome: candidatura.nome || '',
      nome_pai: candidatura.nome_pai || '',
      nome_mae: candidatura.nome_mae || '',
      bi: candidatura.bi || '',
      nif: candidatura.nif || '',
      data_nascimento: candidatura.data_nascimento || '',
      sexo: candidatura.sexo || 'Masculino',
      nacionalidade: candidatura.nacionalidade || 'São-tomense',
      naturalidade: candidatura.naturalidade || 'São Tomé',
      estado_civil: candidatura.estado_civil || 'Solteiro',
      agregado: candidatura.agregado || '1',
      morada: candidatura.morada || '',
      distrito: candidatura.distrito || 'Água Grande',
      zona: candidatura.zona || '',
      contacto: candidatura.contacto || '',
      contacto_alternativo: candidatura.contacto_alternativo || '',
      email: candidatura.email || '',
      habilitacao_literaria: candidatura.habilitacao_literaria || '',
      area_formacao: candidatura.area_formacao || '',
      formacao_profissional: candidatura.formacao_profissional || '',
      experiencia_profissional: candidatura.experiencia_profissional || '',
      ocupacao: candidatura.ocupacao || '',
      motivo_inscricao: candidatura.motivo_inscricao || '',
      situacao_emprego: candidatura.situacao_emprego || '',
      deficiente: Boolean(candidatura.deficiente),
      tipo_deficiencia: candidatura.tipo_deficiencia || '',
      encaminhado_apoio_social: Boolean(candidatura.encaminhado_apoio_social),
      instituicao_apoio_social: candidatura.instituicao_apoio_social || '',
      autorizacao_divulgacao_dados: Boolean(candidatura.autorizacao_divulgacao_dados),
      justificacao_correcao: '',
      recolocar_analise: false,
    });
    setModoEdicao(false);
    setModalReprovarAberto(false);
    setModalAprovarAberto(false);
    setMotivoReprovacao('');
    if (candidatura.documentos && candidatura.documentos.length > 0) {
      setDocSelecionado(candidatura.documentos[0]);
    } else {
      setDocSelecionado(null);
    }
  }, [candidatura]);

  const indexAtual = candidaturasLista.findIndex((c) => c.id === candidatura?.id);
  const temAnterior = indexAtual > 0;
  const temSeguinte = indexAtual >= 0 && indexAtual < candidaturasLista.length - 1;

  const irAnterior = useCallback(() => {
    if (temAnterior && onNavigate) {
      onNavigate(candidaturasLista[indexAtual - 1]);
    }
  }, [temAnterior, candidaturasLista, indexAtual, onNavigate]);

  const irSeguinte = useCallback(() => {
    if (temSeguinte && onNavigate) {
      onNavigate(candidaturasLista[indexAtual + 1]);
    }
  }, [temSeguinte, candidaturasLista, indexAtual, onNavigate]);

  // Teclado
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape' && onClose) {
        onClose();
      } else if (e.key === 'ArrowLeft' && !modoEdicao) {
        irAnterior();
      } else if (e.key === 'ArrowRight' && !modoEdicao) {
        irSeguinte();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose, irAnterior, irSeguinte, modoEdicao]);

  const copiarProtocolo = () => {
    if (!candidatura?.codigo) return;
    navigator.clipboard.writeText(candidatura.codigo);
    setCopiado(true);
    setTimeout(() => setCopiado(false), 2000);
  };

  // Ações de fluxo
  const executarAprovacao = async () => {
    setProcessando(true);
    try {
      const res = await adminApi.aprovarCandidatura(token, candidatura.id, obsAprovacao);
      if (aoNotificar) {
        aoNotificar({
          tipo: 'sucesso',
          texto: `Candidatura Aprovada com sucesso! Formando vinculado (${res?.processo || 'CFP'}) e Inscrição oficial gerada.`,
        });
      }
      setModalAprovarAberto(false);
      if (onAtualizar) await onAtualizar();
      const candAtualizada = await adminApi.obterDetalhesCandidatura(token, candidatura.id);
      if (onNavigate) onNavigate(candAtualizada);
    } catch (err) {
      if (aoNotificar) aoNotificar({ tipo: 'erro', texto: err.message || 'Falha ao aprovar candidatura.' });
    } finally {
      setProcessando(false);
    }
  };

  const executarReprovacao = async () => {
    if (!motivoReprovacao.trim()) {
      if (aoNotificar) aoNotificar({ tipo: 'erro', texto: 'O motivo de reprovação é obrigatório.' });
      return;
    }
    setProcessando(true);
    try {
      await adminApi.reprovarCandidatura(token, candidatura.id, motivoReprovacao);
      if (aoNotificar) {
        aoNotificar({
          tipo: 'sucesso',
          texto: 'Candidatura Reprovada com sucesso (motivo auditado no histórico).',
        });
      }
      setModalReprovarAberto(false);
      setMotivoReprovacao('');
      if (onAtualizar) await onAtualizar();
      const candAtualizada = await adminApi.obterDetalhesCandidatura(token, candidatura.id);
      if (onNavigate) onNavigate(candAtualizada);
    } catch (err) {
      if (aoNotificar) aoNotificar({ tipo: 'erro', texto: err.message || 'Falha ao reprovar candidatura.' });
    } finally {
      setProcessando(false);
    }
  };

  const salvarCorrecoes = async (e) => {
    if (e) e.preventDefault();
    setProcessando(true);
    try {
      await adminApi.atualizarCandidatura(token, candidatura.id, dadosEdicao);
      if (aoNotificar) aoNotificar({ tipo: 'sucesso', texto: 'Dados corrigidos e auditoria gravada com sucesso!' });
      setModoEdicao(false);
      if (onAtualizar) await onAtualizar();
      const candAtualizada = await adminApi.obterDetalhesCandidatura(token, candidatura.id);
      if (onNavigate) onNavigate(candAtualizada);
    } catch (err) {
      if (aoNotificar) aoNotificar({ tipo: 'erro', texto: err.message || 'Erro ao salvar alterações.' });
    } finally {
      setProcessando(false);
    }
  };

  if (!candidatura) return null;
  const fotoDoc = candidatura.documentos?.find((d) => d.tipo === 'FOTO');

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 md:p-6">
      <div className="relative w-full max-w-6xl bg-white rounded-2xl shadow-2xl border border-slate-300 flex flex-col max-h-[94vh] overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* ==================================================================== */}
        {/* CABEÇALHO DO MODAL */}
        {/* ==================================================================== */}
        <div className="px-6 py-4 bg-emerald-950 text-white flex flex-wrap items-center justify-between gap-4 border-b border-emerald-800 shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-emerald-700 border border-emerald-400/40 flex items-center justify-center text-white shadow-inner font-bold text-lg">
              CFP
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <span className="text-xs font-mono font-bold bg-emerald-900 text-emerald-200 px-3 py-1 rounded-md border border-emerald-700 flex items-center gap-1.5">
                  {candidatura.codigo}
                  <button
                    onClick={copiarProtocolo}
                    title="Copiar Protocolo"
                    className="hover:text-white transition-colors cursor-pointer"
                  >
                    {copiado ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                  </button>
                </span>
                <StatusBadgeAdmin estado={candidatura.estado} size="md" />
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 mt-1">
                {candidatura.nome}
                {candidatura.processo_numero && (
                  <span className="text-xs font-semibold text-emerald-300 bg-emerald-900/80 px-2.5 py-0.5 rounded-md border border-emerald-700">
                    Processo: {candidatura.processo_numero}
                  </span>
                )}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => adminApi.baixarFichaOficialPdf(candidatura)}
              title="Baixar Ficha de Inscrição Oficial em PDF (2 Páginas A4)"
              className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white border border-emerald-600 transition-colors flex items-center gap-2 text-xs font-bold shadow-xs cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Ficha PDF</span>
            </button>

            <button
              type="button"
              onClick={() => adminApi.exportarCandidaturaExcel(candidatura)}
              title="Exportar Candidatura para Excel"
              className="px-3.5 py-2 rounded-xl bg-emerald-800 hover:bg-emerald-700 text-white border border-emerald-600 transition-colors flex items-center gap-2 text-xs font-bold shadow-xs cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span className="hidden sm:inline">Excel</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl text-emerald-200 hover:text-white hover:bg-emerald-900 transition-colors cursor-pointer"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* ==================================================================== */}
        {/* NAVEGAÇÃO DE 3 ABAS CLARAS */}
        {/* ==================================================================== */}
        <div className="px-6 bg-slate-100 border-b border-slate-300 flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setAbaAtiva('dossier')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              abaAtiva === 'dossier'
                ? 'border-emerald-700 text-emerald-900 bg-white shadow-2xs rounded-t-xl'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <IdCard className="w-4 h-4 text-emerald-700" />
            <span>1. Dossiê Completo do Candidato</span>
          </button>

          <button
            type="button"
            onClick={() => setAbaAtiva('documentos')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              abaAtiva === 'documentos'
                ? 'border-emerald-700 text-emerald-900 bg-white shadow-2xs rounded-t-xl'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-700" />
            <span>2. Documentos & Anexos ({candidatura.documentos?.length || 0})</span>
          </button>

          <button
            type="button"
            onClick={() => setAbaAtiva('historico')}
            className={`py-3.5 px-4 text-xs font-bold border-b-2 flex items-center gap-2 transition-all cursor-pointer ${
              abaAtiva === 'historico'
                ? 'border-emerald-700 text-emerald-900 bg-white shadow-2xs rounded-t-xl'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-4 h-4 text-emerald-700" />
            <span>3. Histórico de Auditoria ({candidatura.historico?.length || 0})</span>
          </button>
        </div>

        {/* ==================================================================== */}
        {/* CONTEÚDO DAS ABAS */}
        {/* ==================================================================== */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1 space-y-6 bg-slate-50">

          {/* ================================================================ */}
          {/* ABA 1: DOSSIÊ COMPLETO UNIFICADO DO CANDIDATO */}
          {/* ================================================================ */}
          {abaAtiva === 'dossier' && (
            <div className="space-y-6">

              {/* MODO DE EDIÇÃO RÁPIDA / CORREÇÃO */}
              {modoEdicao && (
                <div className="bg-white p-6 rounded-2xl border-2 border-emerald-600 shadow-md space-y-4 animate-in fade-in duration-200">
                  <div className="flex items-center justify-between border-b pb-3">
                    <h3 className="text-base font-bold text-emerald-950 flex items-center gap-2">
                      <Edit3 className="w-5 h-5 text-emerald-700" />
                      Retificar Informações do Candidato
                    </h3>
                    <button
                      type="button"
                      onClick={() => setModoEdicao(false)}
                      className="text-xs text-slate-600 hover:text-slate-900 font-bold"
                    >
                      Cancelar
                    </button>
                  </div>

                  <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-300 text-xs text-amber-900 flex items-center gap-2 font-medium">
                    <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>As alterações feitas ficarão registadas no histórico de auditoria.</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Nome Completo</label>
                      <input
                        type="text"
                        value={dadosEdicao.nome}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, nome: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Nome do Pai</label>
                      <input
                        type="text"
                        value={dadosEdicao.nome_pai}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, nome_pai: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Nome da Mãe</label>
                      <input
                        type="text"
                        value={dadosEdicao.nome_mae}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, nome_mae: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">N.º do Bilhete de Identidade</label>
                      <input
                        type="text"
                        value={dadosEdicao.bi}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, bi: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">NIF (Contribuinte)</label>
                      <input
                        type="text"
                        value={dadosEdicao.nif}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, nif: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Data de Nascimento</label>
                      <input
                        type="date"
                        value={dadosEdicao.data_nascimento}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, data_nascimento: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Distrito</label>
                      <input
                        type="text"
                        value={dadosEdicao.distrito}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, distrito: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Morada / Localidade</label>
                      <input
                        type="text"
                        value={dadosEdicao.morada}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, morada: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Contacto Telefónico</label>
                      <input
                        type="text"
                        value={dadosEdicao.contacto}
                        onChange={(e) => setDadosEdicao({ ...dadosEdicao, contacto: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Justificação da Correção
                    </label>
                    <input
                      type="text"
                      value={dadosEdicao.justificacao_correcao}
                      onChange={(e) => setDadosEdicao({ ...dadosEdicao, justificacao_correcao: e.target.value })}
                      placeholder="Indique a justificação da alteração..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="recolocar_analise_check"
                      checked={dadosEdicao.recolocar_analise}
                      onChange={(e) => setDadosEdicao({ ...dadosEdicao, recolocar_analise: e.target.checked })}
                      className="rounded text-emerald-600 focus:ring-emerald-500 h-4 w-4"
                    />
                    <label htmlFor="recolocar_analise_check" className="text-xs font-bold text-slate-800 cursor-pointer">
                      Recolocar candidatura no estado EM_ANALISE
                    </label>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => setModoEdicao(false)}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={salvarCorrecoes}
                      disabled={processando}
                      className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      <span>{processando ? 'A Gravar...' : 'Salvar Alterações'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* CARTÃO 1: IDENTIFICAÇÃO PESSOAL & FILIAÇÃO */}
              <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-xs space-y-5">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5">
                    <User className="w-4 h-4 text-emerald-700" />
                    Identificação do Candidato & Registo Civil
                  </h3>
                  <span className="text-xs font-bold text-slate-500">
                    N.º Protocolo: <strong className="text-slate-900 font-mono">{candidatura.codigo}</strong>
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                  {/* Foto Passe */}
                  <div className="md:col-span-3 flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl border border-slate-200 text-center">
                    <div className="w-36 h-44 rounded-xl bg-white border-2 border-slate-300 overflow-hidden flex items-center justify-center shadow-xs">
                      {fotoDoc?.download_url ? (
                        <img
                          src={fotoDoc.download_url}
                          alt="Foto Passe"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center p-3 text-slate-400">
                          <User className="w-12 h-12 mx-auto mb-1 opacity-40 text-slate-500" />
                          <span className="text-xs font-semibold">Sem Fotografia</span>
                        </div>
                      )}
                    </div>
                    <span className="text-xs font-bold text-slate-700 mt-2">Fotografia Oficial</span>
                  </div>

                  {/* Dados de Identificação */}
                  <div className="md:col-span-9 grid grid-cols-2 sm:grid-cols-3 gap-5 text-sm">
                    <div className="sm:col-span-2">
                      <span className="text-xs font-bold text-slate-500 block uppercase">Nome Completo</span>
                      <span className="font-bold text-slate-950 text-base">{candidatura.nome}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Bilhete de Identidade (BI)</span>
                      <span className="font-bold text-slate-900 text-base font-mono">{candidatura.bi}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">NIF (Contribuinte)</span>
                      <span className="font-bold text-slate-900 text-base font-mono">{candidatura.nif || '—'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Data de Nascimento</span>
                      <span className="font-bold text-slate-900 text-base">{candidatura.data_nascimento}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Idade</span>
                      <span className="font-bold text-emerald-800 text-base">{candidatura.idade ? `${candidatura.idade} anos` : '—'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Sexo</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.sexo}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Estado Civil</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.estado_civil || 'Solteiro(a)'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Nacionalidade</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.nacionalidade || 'São-tomense'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Naturalidade</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.naturalidade || 'São Tomé'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Nome do Pai</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.nome_pai || '—'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Nome da Mãe</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.nome_mae || '—'}</span>
                    </div>

                    <div>
                      <span className="text-xs font-bold text-slate-500 block uppercase">Agregado Familiar</span>
                      <span className="font-semibold text-slate-900 text-base">{candidatura.agregado || '1'} pessoa(s)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* CARTÃO 2: CONTACTOS & RESIDÊNCIA */}
              <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5 border-b border-slate-200 pb-3">
                  <MapPin className="w-4 h-4 text-emerald-700" />
                  Contactos & Localização
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 text-sm">
                  <div>
                    <span className="text-xs font-bold text-slate-500 block uppercase">Distrito Oficial</span>
                    <span className="font-bold text-slate-900 text-base flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-4 h-4 text-emerald-600" />
                      {candidatura.distrito}
                    </span>
                  </div>

                  <div className="sm:col-span-2">
                    <span className="text-xs font-bold text-slate-500 block uppercase">Morada / Localidade</span>
                    <span className="font-semibold text-slate-900 text-base mt-0.5 block">{candidatura.morada}</span>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-500 block uppercase">Telefone Principal</span>
                    <span className="font-bold text-slate-950 text-base flex items-center gap-1.5 mt-0.5">
                      <Phone className="w-4 h-4 text-emerald-600" />
                      {candidatura.contacto}
                    </span>
                  </div>

                  <div>
                    <span className="text-xs font-bold text-slate-500 block uppercase">Contacto Alternativo</span>
                    <span className="font-semibold text-slate-800 text-base mt-0.5 block">{candidatura.contacto_alternativo || '—'}</span>
                  </div>

                  <div className="sm:col-span-2">
                    <span className="text-xs font-bold text-slate-500 block uppercase">Email</span>
                    <span className="font-semibold text-slate-900 text-base flex items-center gap-1.5 mt-0.5">
                      <Mail className="w-4 h-4 text-emerald-600" />
                      {candidatura.email || '—'}
                    </span>
                  </div>
                </div>
              </div>

              {/* CARTÃO 3: HABILITAÇÕES & EXPERIÊNCIA */}
              <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5 border-b border-slate-200 pb-3">
                  <GraduationCap className="w-4 h-4 text-emerald-700" />
                  Habilitações Literárias & Situação Profissional
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 text-sm">
                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <span className="text-xs font-bold text-slate-500 uppercase block">Habilitação Literária Concluída</span>
                    <span className="font-bold text-slate-950 text-base block">{candidatura.habilitacao_literaria || '—'}</span>
                    {candidatura.area_formacao && (
                      <span className="text-xs font-semibold text-slate-700 block mt-1">Área: {candidatura.area_formacao}</span>
                    )}
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <span className="text-xs font-bold text-slate-500 uppercase block">Situação perante o Emprego</span>
                    <span className="font-bold text-emerald-900 text-base block">{candidatura.situacao_emprego || '—'}</span>
                    {candidatura.ocupacao && (
                      <span className="text-xs font-semibold text-slate-700 block mt-1">Ocupação: {candidatura.ocupacao}</span>
                    )}
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <span className="text-xs font-bold text-slate-500 uppercase block">Formação Profissional Anterior</span>
                    <p className="text-sm text-slate-900 font-medium leading-relaxed">{candidatura.formacao_profissional || 'Nenhuma declarada.'}</p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
                    <span className="text-xs font-bold text-slate-500 uppercase block">Experiência Profissional</span>
                    <p className="text-sm text-slate-900 font-medium leading-relaxed">{candidatura.experiencia_profissional || 'Nenhuma declarada.'}</p>
                  </div>
                </div>
              </div>

              {/* CARTÃO 4: CURSOS PRETENDIDOS */}
              <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5 border-b border-slate-200 pb-3">
                  <Award className="w-4 h-4 text-emerald-700" />
                  Cursos Escolhidos & Opções
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="p-5 rounded-xl border-2 border-emerald-500 bg-emerald-50/50 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full bg-emerald-700 text-white text-xs font-bold uppercase">
                        1.ª Opção Prioritária
                      </span>
                      <span className="text-xs font-bold text-emerald-950">{candidatura.programa?.nome || 'Qualificação Inicial'}</span>
                    </div>
                    <h4 className="text-lg font-bold text-emerald-950">{candidatura.curso_opcao1?.nome || 'Curso 1ª Opção'}</h4>
                    <div className="grid grid-cols-2 gap-3 text-xs text-emerald-950 pt-2 border-t border-emerald-200 font-medium">
                      <div>
                        <span className="text-slate-600 block font-bold">Horário:</span>
                        <span className="text-sm font-bold text-slate-900">{candidatura.curso_opcao1?.horario || 'Diurno'}</span>
                      </div>
                      <div>
                        <span className="text-slate-600 block font-bold">Local:</span>
                        <span className="text-sm font-bold text-slate-900">{candidatura.curso_opcao1?.local_realizacao || 'CFP-STP'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-5 rounded-xl border border-slate-300 bg-slate-50 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="px-3 py-1 rounded-full bg-slate-600 text-white text-xs font-bold uppercase">
                        2.ª Opção Alternativa
                      </span>
                      <span className="text-xs font-bold text-slate-700">{candidatura.curso_opcao2?.programa_nome || '—'}</span>
                    </div>
                    <h4 className="text-lg font-bold text-slate-900">{candidatura.curso_opcao2?.nome || 'Nenhuma 2ª opção selecionada'}</h4>
                    {candidatura.curso_opcao2 && (
                      <div className="grid grid-cols-2 gap-3 text-xs text-slate-700 pt-2 border-t border-slate-200 font-medium">
                        <div>
                          <span className="text-slate-600 block font-bold">Horário:</span>
                          <span className="text-sm font-bold text-slate-900">{candidatura.curso_opcao2.horario || '—'}</span>
                        </div>
                        <div>
                          <span className="text-slate-600 block font-bold">Local:</span>
                          <span className="text-sm font-bold text-slate-900">{candidatura.curso_opcao2.local_realizacao || '—'}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm">
                  <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Motivo da Inscrição:</span>
                  <p className="text-slate-900 font-medium italic">"{candidatura.motivo_inscricao || 'Qualificação técnica profissional no CFP-STP.'}"</p>
                </div>
              </div>

              {/* CARTÃO 5: CASOS ESPECIAIS & APOIO SOCIAL */}
              <div className="bg-white p-6 rounded-2xl border border-slate-300 shadow-xs space-y-4">
                <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5 border-b border-slate-200 pb-3">
                  <HeartHandshake className="w-4 h-4 text-emerald-700" />
                  Casos Especiais & Apoio Social
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-sm">
                  <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-300">
                    <span className="font-bold text-amber-950 block text-xs uppercase">Necessidade Especial / Deficiência:</span>
                    <span className="text-base font-bold text-amber-950 mt-1 block">
                      {candidatura.deficiente ? `Sim (${candidatura.tipo_deficiencia || 'Especificado'})` : 'Não'}
                    </span>
                  </div>
                  <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-300">
                    <span className="font-bold text-amber-950 block text-xs uppercase">Encaminhado por Apoio Social:</span>
                    <span className="text-base font-bold text-amber-950 mt-1 block">
                      {candidatura.encaminhado_apoio_social ? `Sim (${candidatura.instituicao_apoio_social || 'Instituição'})` : 'Não'}
                    </span>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* ================================================================ */}
          {/* ABA 2: DOCUMENTOS & ANEXOS COM VISUALIZADOR */}
          {/* ================================================================ */}
          {abaAtiva === 'documentos' && (
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-300 shadow-xs space-y-6">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5">
                    <FileText className="w-5 h-5 text-emerald-700" />
                    Dossiê de Documentos Anexados
                  </h3>
                  <p className="text-xs font-medium text-slate-500 mt-0.5">
                    Consulte os ficheiros originais submetidos pelo candidato para validação documental.
                  </p>
                </div>
                <span className="text-xs font-bold text-emerald-800 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                  {candidatura.documentos?.length || 0} Ficheiro(s) Anexo(s)
                </span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Lista de Ficheiros */}
                <div className="space-y-3">
                  {candidatura.documentos && candidatura.documentos.length > 0 ? (
                    candidatura.documentos.map((doc) => (
                      <button
                        key={doc.id}
                        type="button"
                        onClick={() => setDocSelecionado(doc)}
                        className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center justify-between cursor-pointer ${
                          docSelecionado?.id === doc.id
                            ? 'bg-emerald-50 border-emerald-600 shadow-sm'
                            : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:bg-slate-100'
                        }`}
                      >
                        <div className="flex items-center gap-3 truncate">
                          <FileCheck className={`w-5 h-5 shrink-0 ${docSelecionado?.id === doc.id ? 'text-emerald-700' : 'text-slate-500'}`} />
                          <div className="truncate">
                            <span className="text-sm font-bold text-slate-900 block truncate">{doc.tipo}</span>
                            <span className="text-xs text-slate-500 truncate block font-mono">{doc.nome_original}</span>
                          </div>
                        </div>
                        <Eye className="w-4 h-4 text-slate-400 shrink-0" />
                      </button>
                    ))
                  ) : (
                    <div className="p-8 text-center text-slate-400 border-2 border-dashed rounded-2xl bg-slate-50">
                      <FileText className="w-10 h-10 mx-auto mb-2 text-slate-400" />
                      <p className="text-sm font-bold text-slate-700">Nenhum documento digital anexado.</p>
                    </div>
                  )}
                </div>

                {/* Pré-visualizador em tempo real */}
                <div className="lg:col-span-2 bg-slate-950 rounded-2xl p-4 border border-slate-800 min-h-[360px] flex flex-col justify-center items-center text-white overflow-hidden shadow-inner">
                  {docSelecionado ? (
                    <div className="w-full h-full flex flex-col items-center justify-center space-y-4">
                      <div className="flex items-center justify-between w-full px-3 text-xs font-semibold text-slate-300 border-b border-slate-800 pb-2">
                        <span>{docSelecionado.tipo} · {docSelecionado.nome_original}</span>
                        <a
                          href={docSelecionado.download_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-emerald-400 hover:text-emerald-300 font-bold flex items-center gap-1.5"
                        >
                          Abrir Noutro Separador <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>

                      {docSelecionado.mimetype?.includes('image') || String(docSelecionado.download_url).startsWith('data:image') ? (
                        <img
                          src={docSelecionado.download_url}
                          alt={docSelecionado.tipo}
                          className="max-h-[280px] object-contain rounded-xl border border-slate-800"
                        />
                      ) : (
                        <div className="p-8 text-center space-y-3">
                          <FileText className="w-16 h-16 text-emerald-400 mx-auto" />
                          <p className="text-sm text-slate-200 font-semibold">Documento em formato PDF ou digital anexado.</p>
                          <a
                            href={docSelecionado.download_url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md"
                          >
                            <Eye className="w-4 h-4" />
                            Visualizar Documento Completo
                          </a>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-slate-500">
                      <Eye className="w-12 h-12 mx-auto mb-2 opacity-40 text-slate-400" />
                      <p className="text-sm font-medium">Selecione um ficheiro ao lado para pré-visualizar em tempo real.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ================================================================ */}
          {/* ABA 3: HISTÓRICO DE AUDITORIA */}
          {abaAtiva === 'historico' && (
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-300 shadow-xs space-y-6">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div>
                  <h3 className="text-base font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2.5">
                    <History className="w-5 h-5 text-emerald-700" />
                    Histórico de Auditoria & Ciclo de Vida
                  </h3>
                  <p className="text-xs font-medium text-slate-500 mt-0.5">
                    Registo de todas as ações, transições de estado e pareceres técnicos.
                  </p>
                </div>
              </div>

              {candidatura.historico && candidatura.historico.length > 0 ? (
                <div className="relative pl-8 space-y-6 before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {candidatura.historico.map((h, idx) => (
                    <div key={h.id || idx} className="relative space-y-1.5">
                      <div className="absolute -left-[31px] top-1 w-4 h-4 rounded-full bg-emerald-600 ring-4 ring-emerald-100" />
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-bold text-slate-900">{h.acao}</span>
                        <span className="text-slate-500 font-mono text-xs">{h.data_registo}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-slate-600 font-medium">
                        <span>Operador: <strong className="text-slate-900">{h.utilizador_nome || 'Sistema'}</strong></span>
                        {h.estado_anterior && h.estado_novo && (
                          <span className="bg-slate-100 px-2.5 py-0.5 rounded-md border border-slate-200 text-slate-800 font-semibold">
                            {h.estado_anterior} → {h.estado_novo}
                          </span>
                        )}
                      </div>
                      {h.observacao && (
                        <p className="text-xs text-slate-800 bg-slate-50 p-3 rounded-xl border border-slate-200 mt-1 leading-relaxed">
                          {h.observacao}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center text-slate-400">
                  <Clock className="w-10 h-10 mx-auto mb-2 text-slate-400" />
                  <p className="text-sm font-bold text-slate-700">Sem registos adicionais de auditoria.</p>
                </div>
              )}
            </div>
          )}

        </div>

        {/* ==================================================================== */}
        {/* MODAL FLUTUANTE DE REPROVAÇÃO */}
        {/* ==================================================================== */}
        {modalReprovarAberto && (
          <div className="absolute inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-rose-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center gap-2 text-rose-700 font-bold text-lg">
                <XCircle className="w-6 h-6" />
                <span>Reprovar Candidatura</span>
              </div>
              <p className="text-xs text-slate-700 font-medium">
                Indique obrigatoriamente o motivo da não admissão do candidato. O dossiê passará para o estado <strong>REJEITADA</strong> e a justificação ficará auditada.
              </p>
              <textarea
                rows={3}
                value={motivoReprovacao}
                onChange={(e) => setMotivoReprovacao(e.target.value)}
                placeholder="Introduza o parecer detalhado da reprovação..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 focus:ring-2 focus:ring-rose-500 focus:outline-none"
                autoFocus
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalReprovarAberto(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={processando || !motivoReprovacao.trim()}
                  onClick={executarReprovacao}
                  className="px-5 py-2 rounded-xl bg-rose-700 hover:bg-rose-800 text-white text-xs font-bold shadow-xs disabled:opacity-50"
                >
                  {processando ? 'A Reprovar...' : 'Confirmar Reprovação'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================== */}
        {/* MODAL FLUTUANTE DE APROVAÇÃO */}
        {/* ==================================================================== */}
        {modalAprovarAberto && (
          <div className="absolute inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl p-6 max-w-lg w-full shadow-2xl border border-emerald-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center gap-2 text-emerald-800 font-bold text-lg">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                <span>Homologar e Aprovar Candidatura</span>
              </div>
              <p className="text-xs text-slate-700 font-medium">
                Esta ação integrará o candidato como <strong>Formando Oficial do CFP</strong>, gerando o número de processo e criando o registo oficial na tabela de Inscrições.
              </p>
              <textarea
                rows={2}
                value={obsAprovacao}
                onChange={(e) => setObsAprovacao(e.target.value)}
                placeholder="Observação da comissão técnica (opcional)..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalAprovarAberto(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  disabled={processando}
                  onClick={executarAprovacao}
                  className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shadow-xs disabled:opacity-50"
                >
                  {processando ? 'A Homologar...' : 'Confirmar Aprovação Oficial'}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ==================================================================== */}
        {/* RODAPÉ DO MODAL COM BOTÕES DISTRIBUÍDOS */}
        {/* ==================================================================== */}
        <div className="px-6 py-4 bg-slate-100 border-t border-slate-300 flex flex-wrap items-center justify-between gap-3 shrink-0">
          
          {/* LADO ESQUERDO: NAVEGAÇÃO ANTERIOR / SEGUINTE */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={irAnterior}
              disabled={!temAnterior || processando}
              title="Candidato Anterior (←)"
              className="px-3.5 py-2.5 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-800 font-bold text-xs flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-2xs"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Anterior</span>
            </button>

            <span className="text-xs text-slate-600 font-mono font-bold px-2">
              {indexAtual >= 0 ? indexAtual + 1 : 1} / {candidaturasLista.length || 1}
            </span>

            <button
              type="button"
              onClick={irSeguinte}
              disabled={!temSeguinte || processando}
              title="Próximo Candidato (→)"
              className="px-4 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white font-bold text-xs flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
            >
              <span>Próximo Candidato</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* LADO DIREITO: CORRIGIR, REPROVAR, APROVAR & FECHAR */}
          <div className="flex flex-wrap items-center gap-2.5">
            
            {/* Botão Corrigir Dados */}
            <button
              type="button"
              onClick={() => {
                setAbaAtiva('dossier');
                setModoEdicao(!modoEdicao);
              }}
              disabled={processando}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                modoEdicao
                  ? 'bg-amber-100 border-2 border-amber-400 text-amber-950'
                  : 'bg-white border border-slate-300 hover:bg-slate-50 text-slate-800'
              }`}
            >
              <Edit3 className="w-4 h-4 text-emerald-700" />
              <span>{modoEdicao ? 'Cancelar Edição' : 'Corrigir'}</span>
            </button>

            {/* Botão Reprovar */}
            <button
              type="button"
              disabled={processando || candidatura.estado === 'APROVADA' || candidatura.estado === 'CANCELADA'}
              onClick={() => setModalReprovarAberto(true)}
              className="px-4 py-2.5 rounded-xl bg-rose-700 hover:bg-rose-800 active:bg-rose-900 text-white font-bold text-xs transition-all flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
            >
              <XCircle className="w-4 h-4" />
              <span>Reprovar</span>
            </button>

            {/* Botão Aprovar */}
            <button
              type="button"
              disabled={processando || candidatura.estado === 'APROVADA' || candidatura.estado === 'CANCELADA'}
              onClick={() => setModalAprovarAberto(true)}
              className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs transition-all flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-xs"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Aprovar</span>
            </button>

            {/* Botão Fechar */}
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-all cursor-pointer shadow-xs"
            >
              Fechar
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
