import React, { useState } from 'react';
import { AdminGestaoView } from './components/AdminGestaoView.jsx';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';

export const ModuloAdminApp = ({
  token = typeof window !== 'undefined' && window.localStorage ? localStorage.getItem('token') : 'demo-admin-token-cfp-stp',
}) => {
  const [notificacao, setNotificacao] = useState(null);

  const aoNotificar = (msg) => {
    setNotificacao(msg);
    if (msg) {
      setTimeout(() => setNotificacao(null), 6000);
    }
  };

  return (
    <div className="w-full font-sans bg-slate-50 min-h-screen text-slate-900 p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Toast de Notificação */}
      {notificacao && (
        <div
          className={`fixed top-4 right-4 z-50 p-4 rounded-xl shadow-xl border text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 ${
            notificacao.tipo === 'sucesso'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : 'bg-rose-50 text-rose-900 border-rose-300'
          }`}
        >
          {notificacao.tipo === 'sucesso' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{notificacao.texto}</span>
          <button
            onClick={() => setNotificacao(null)}
            className="ml-2 hover:opacity-75 cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Painel Principal de Gestão de Dossiês */}
      <AdminGestaoView
        token={token}
        aoNotificar={aoNotificar}
      />
    </div>
  );
};

export default ModuloAdminApp;
export * from './services/adminApi';
export * from './api/urls';
