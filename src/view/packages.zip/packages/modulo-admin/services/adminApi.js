import { converterCandidaturaAdminParaDadosFicha } from '../utils/adminMapper';

import * as XLSX from 'xlsx';
import { gerarPdfFormularioInscricao } from '../utils/gerarPdfInscricao';
import { exportarInscricaoParaExcel } from '../utils/pdfFichaGenerator';
import { API_URL } from '../../../../api/urls';

/**
 * Constrói a URL completa para a API externa ou fallback local
 */
export function buildApiUrl(endpoint) {
  const base = (API_URL || '').trim().replace(/\/+$/, '');
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  if (!base) return cleanEndpoint;
  return `${base}${cleanEndpoint}`;
}

/**
 * Executa fetch prioritariamente contra a API_URL configurada com fallback local caso a rede remota esteja indisponível
 */
async function fetchComFallback(endpoint, options = {}) {
  const remoteUrl = buildApiUrl(endpoint);
  
  try {
    const res = await fetch(remoteUrl, options);
    return res;
  } catch (err) {
    if (remoteUrl !== endpoint && (err.name === 'TypeError' || err.message?.includes('Failed to fetch') || err.message?.includes('NetworkError'))) {
      console.warn(`[adminApi] Falha ao contactar ${remoteUrl}, a utilizar endpoint local /api...`);
      return await fetch(endpoint, options);
    }
    throw err;
  }
}

export const adminApi = {
  async listarCandidaturas(token, filtros = {}) {
    const params = new URLSearchParams();
    if (filtros.estado) params.append('estado', filtros.estado);
    if (filtros.pesquisa) params.append('pesquisa', filtros.pesquisa);
    if (filtros.programa_id) params.append('programa_id', String(filtros.programa_id));
    if (filtros.curso_id) params.append('curso_id', String(filtros.curso_id));
    if (filtros.distrito) params.append('distrito', filtros.distrito);
    if (filtros.ano) params.append('ano', String(filtros.ano));
    if (filtros.data_inicio) params.append('data_inicio', filtros.data_inicio);
    if (filtros.data_fim) params.append('data_fim', filtros.data_fim);
    if (filtros.page) params.append('page', String(filtros.page));
    if (filtros.per_page) params.append('per_page', String(filtros.per_page));

    const queryStr = params.toString() ? `?${params.toString()}` : '';
    const res = await fetchComFallback(`/api/admin/candidaturas${queryStr}`, {
      headers: { Authorization: `Bearer ${token || ''}` },
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.erro || 'Erro ao carregar lista de inscrições.');
    }
    return json;
  },

  async obterDetalhesCandidatura(token, id) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}`, {
      headers: { Authorization: `Bearer ${token || ''}` },
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.erro || 'Erro ao carregar detalhes da candidatura.');
    }
    return json;
  },

  async atualizarCandidatura(token, id, dados) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify(dados),
    });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.erro || 'Erro ao atualizar dados da candidatura.');
    }
    return json;
  },

  async iniciarAnalise(token, id) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/analise`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token || ''}` },
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao iniciar análise.');
    return json;
  },

  async devolverCandidatura(token, id, motivo) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/devolver`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify({ motivo }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao devolver candidatura.');
    return json;
  },

  async aprovarCandidatura(token, id, observacao) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/aprovar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify({
        observacao:
          observacao ||
          'Candidatura aprovada pela comissão técnica e homologada oficialmente no sistema administrativo.',
      }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Falha na aprovação.');
    return json;
  },

  async rejeitarCandidatura(token, id, motivo) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/rejeitar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify({ motivo }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao rejeitar candidatura.');
    return json;
  },

  async reprovarCandidatura(token, id, motivo) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/reprovar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify({ motivo }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao reprovar candidatura.');
    return json;
  },

  async cancelarCandidatura(token, id, motivo) {
    const res = await fetchComFallback(`/api/admin/candidaturas/${id}/cancelar`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token || ''}`,
      },
      body: JSON.stringify({ motivo }),
    });
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao cancelar candidatura.');
    return json;
  },

  async listarProgramas() {
    const res = await fetchComFallback('/api/programas');
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao carregar programas.');
    return json;
  },

  async listarCursos(programaId) {
    const url = programaId ? `/api/cursos?programa_id=${programaId}` : '/api/cursos';
    const res = await fetchComFallback(url);
    const json = await res.json();
    if (!res.ok) throw new Error(json.erro || 'Erro ao carregar cursos.');
    return json;
  },

  baixarFichaOficialPdf(cand) {
    const dadosFicha = converterCandidaturaAdminParaDadosFicha(cand);
    gerarPdfFormularioInscricao(dadosFicha);
  },

  exportarCandidaturaExcel(cand) {
    const dadosFicha = converterCandidaturaAdminParaDadosFicha(cand);
    exportarInscricaoParaExcel(dadosFicha);
  },

  async exportarTodasCandidaturasExcel(token, _filtros = {}) {
    const res = await fetchComFallback('/api/admin/candidaturas/exportar-excel', {
      headers: { Authorization: `Bearer ${token || ''}` },
    });
    const data = await res.json();
    const lista = data.candidaturas || [];

    const linhas = lista.map((c) => ({
      Código: c.codigo,
      Estado: c.estado,
      'Processo Formando': c.processo_numero || '—',
      Nome: c.nome,
      BI: c.bi,
      NIF: c.nif || '—',
      'Data Nasc.': c.data_nascimento,
      Idade: c.idade || '',
      Sexo: c.sexo,
      Distrito: c.distrito,
      Morada: c.morada,
      Telefone: c.contacto,
      Email: c.email || '—',
      Habilitação: c.habilitacao_literaria,
      Programa: c.programa?.nome || '',
      '1.ª Opção Curso': c.curso_opcao1?.nome || '',
      '2.ª Opção Curso': c.curso_opcao2?.nome || '—',
      'Situação Emprego': c.situacao_emprego || '—',
      'Data Inscrição': c.data_submissao || c.data_criacao,
    }));

    const ws = XLSX.utils.json_to_sheet(linhas);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Candidaturas CFP');
    XLSX.writeFile(wb, `Listagem_Candidaturas_CFP_${new Date().toISOString().slice(0, 10)}.xlsx`);
  },
};
